function validacion(){
    valor = document.getElementById("usuarioform").value;
    valor2= document.getElementById("passwordform").value;
if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
  alert("[Error] debe rellenar el campo")  
  return false;
}
else if (valor!="admin"){
    alert("[Error] No se reconoce Usuario")
    return false;
}
else if (valor2 == null || valor2.length==0 || /^\s+$/.test(valor2)){
    alert("[Error] Campo de clave Vacío")
    return false;
}
else if (valor2!="1234"){
    alert("[Error] Clave Incorrecta")
    return false;
}
return true;
window.location = "agregarcliente.html";
}